//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport
import AVFoundation
import Darwin

var suonoTreno: AVAudioPlayer?
var narratore: AVAudioPlayer?

let path1 = Bundle.main.path(forResource: "Matteo.m4a", ofType:nil)!
let url1 = URL(fileURLWithPath: path1)

let path = Bundle.main.path(forResource: "0012626.mp3", ofType:nil)!
let url = URL(fileURLWithPath: path)

var click : Bool = false

if ( click == false ) {
    suonoTreno = try AVAudioPlayer(contentsOf: url)
    suonoTreno?.play()
}

struct ScenaDue: View {
    var body: some View {
        
        VStack{
            Text("Luis is waiting for the metro when he hears two guys talking about a new videogame. ")
                .italic()
                .frame(width:400)
                .scaledToFit()
                .lineLimit(4)
                .font(.system(size: 24, weight: .bold, design: .serif))
            
            HStack {
                Image(uiImage: #imageLiteral(resourceName: "firstscene.jpg"))
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 400, height: 400)
            }
            
            Button {
            }label:{
                Text("PLAY STORY")
                    .foregroundColor(.white)
                    .bold()
                    .padding(10).background(.black)
                    .cornerRadius(10)
                    .position(x:150,y:50)
                    .scaledToFit()
                
                    .onTapGesture (count:1){
                        click = true
                        do {
                            narratore = try AVAudioPlayer(contentsOf: url1)
                            narratore?.play()
                        } catch {
                        }
                    }
            }
            
        }
        .frame(width: 400, height: 600)
    }
}
PlaygroundPage.current.setLiveView(ScenaDue())
//: [Next](@next)
