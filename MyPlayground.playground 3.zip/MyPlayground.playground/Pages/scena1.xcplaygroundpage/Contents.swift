import SwiftUI
import PlaygroundSupport
import AVFoundation
import AudioToolbox



struct ScenaUno: View {
    var body: some View {
        
        
        ZStack {
            
            VStack{
                
                Image(uiImage: UIImage(named:"name_tk2.jpg")!)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 400, height: 600)
            }
            
            Spacer()
            
        }
    }
}


PlaygroundPage.current.setLiveView(ScenaUno())

//: [Next](@next)
