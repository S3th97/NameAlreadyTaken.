//: [Previous](@previous)


import SwiftUI
import PlaygroundSupport
import AVFoundation


var barSound : AVAudioPlayer?
var narratore : AVAudioPlayer?

let path2 = Bundle.main.path(forResource: "bar.mp3", ofType:nil)!
let url2 = URL(fileURLWithPath: path2)

let path3 = Bundle.main.path(forResource: "matteospritz.m4a", ofType:nil)!
let url3 = URL(fileURLWithPath: path3)

do {
    barSound = try AVAudioPlayer(contentsOf: url2)
    barSound?.play()
} catch {
    
}


struct ContentView : View {
    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named:"Spritz.png")!)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 200, height: 350)
            
            
                .frame(width:400, height: 600)
            
            VStack{
                
                Text("At night, Luis, while drinking, sees a Spritz that catches his attention and tries to sign up one last time.")
                    .font(.system(size: 24, weight: .light, design: .serif))
                    .italic()
                    .lineLimit(6)
                    .frame(width: 400, height: 200, alignment: .leading)
                    .position(x: 200, y: 70)
                
                Spacer()
                
                Button {
                } label :{
                    Text ("PLAY STORY")
                        .foregroundColor(.white)
                        .bold()
                        .padding(10).background(.blue)
                        .cornerRadius(10)
                        .position(x: 200, y: 100)
                        .scaledToFit()
                    
                        .onTapGesture (count : 1){
                            do {
                                narratore = try AVAudioPlayer(contentsOf: url3)
                                narratore?.play()
                                narratore?.volume = 5
                            } catch {
                                
                            }
                            
                        }
                    
                }
            }
        }
    }
    
    
}


PlaygroundPage.current.setLiveView(ContentView())
//: [Next](@next)
