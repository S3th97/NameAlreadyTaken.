//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport
import AVFoundation

var suonovideo: AVAudioPlayer?
var narratore: AVAudioPlayer?

let path1 = Bundle.main.path(forResource: "Matteo2.m4a", ofType:nil)!
let url1 = URL(fileURLWithPath: path1)

let path = Bundle.main.path(forResource: "video.mp3", ofType:nil)!
let url = URL(fileURLWithPath: path)


var click : Bool = false

if ( click == false ) {
    suonovideo = try AVAudioPlayer(contentsOf: url)
    suonovideo?.play()
}


struct ContentView : View {
    var body: some View {
        ZStack {
            
            HStack{
                Image(uiImage: UIImage(named:"scena3.jpg")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 400, height: 600)
                
                
                    .frame(width:400, height: 600)
            }
            VStack{
                Text("Arrived at home, he starts watching trailers and gameplays all night long.")
                    .italic()
                    .frame(width:400)
                    .scaledToFit()
                    .lineLimit(4)
                    .font(.system(size: 24, weight: .bold, design: .serif))
                
                Spacer()
                
                Button {
                } label :{
                    Text ("PLAY STORY")
                        .foregroundColor(.white)
                        .bold()
                        .padding(10).background(.black)
                        .cornerRadius(10)
                        .position(x:200 , y:70)
                        .scaledToFit()
                        .onTapGesture (count:1){
                            do {
                                narratore = try AVAudioPlayer(contentsOf: url1)
                                narratore?.play()
                            } catch {
                            }
                        }
                }
            }
            
            
        }
    }
    
}

PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
