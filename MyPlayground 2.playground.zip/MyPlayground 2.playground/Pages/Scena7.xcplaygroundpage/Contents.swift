//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport
import AVFoundation
import Darwin

var ptiSound : AVAudioPlayer?


let path2 = Bundle.main.path(forResource: "pti.m4a", ofType:nil)!
let url2 = URL(fileURLWithPath: path2)
struct ContentView : View {
    
    @State var username : String = ""
    @State var popup : Bool = false
    
    var body: some View {
        ZStack
        {
            
            Image(uiImage: UIImage(named:"screen.png")!)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 400, height: 600)
            
            
            VStack{

                TextField ("Insert Spritz as username", text: $username)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .foregroundColor(.black)
                    .font(.headline)
                
                
                Button(action: signin) {
                    Text("Sign Up")
                        .padding().background(.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .popover(isPresented: $popup) {
                            Text(" Registration Successfull")
                                .font(.headline)
                                .padding().background(.orange)
                                .foregroundColor(.white)
                            
                        }
                
                }
              
                
            }
        
        }
        
    }
    
    
    
    func signin() {
        popup = true
        do {
            ptiSound = try AVAudioPlayer(contentsOf: url2)
            ptiSound?.play()
        } catch {
        }
    }
    
}


PlaygroundPage.current.setLiveView(ContentView())


//: [Next](@next)
