//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport
import AVFoundation

var narratore : AVAudioPlayer?
var music : AVAudioPlayer?

let path2 = Bundle.main.path(forResource: "matteofinale.m4a", ofType:nil)!
let url2 = URL(fileURLWithPath: path2)

let path3 = Bundle.main.path(forResource: "gta.mp3", ofType:nil)!
let url3 = URL(fileURLWithPath: path3)

do {
    music = try AVAudioPlayer(contentsOf: url3)
    music?.play()
} catch {

}

struct ContentView : View {
    var body: some View {
        ZStack {


            Image(uiImage: UIImage(named:"gtascena8.jpg")!)
                 .resizable()
                 .aspectRatio(contentMode: .fill)
                 .frame(width: 200, height: 350)


    .frame(width:400, height: 600)

            VStack{

                Text("Luis, eager to play the game, runs out of the bar, when all of a sudden an ambulance swerves and runs over him.")
                    .font(.system(size: 24, weight: .light, design: .serif))
                        .italic()
                    .lineLimit(6)
                    .frame(width: 400, height: 200, alignment: .leading)
                    .position(x: 200, y: 70)

            Spacer()

                Button {
            } label :{
                Text ("PLAY STORY")
                    .foregroundColor(.white)
                    .bold()
                    .padding(10).background(.red)
                    .cornerRadius(10)
                    .position(x: 200, y: 80)
                    .scaledToFit()

                    .onTapGesture (count : 1){
                        do {
                            narratore = try AVAudioPlayer(contentsOf: url2)
                            narratore?.play()
                            narratore?.volume = 6
                        } catch {

                 }
                    }

                    }
            }
        }
    }


}


PlaygroundPage.current.setLiveView(ContentView())
