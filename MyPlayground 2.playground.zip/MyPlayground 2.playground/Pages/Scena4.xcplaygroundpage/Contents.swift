//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport
import AVFoundation


var errorSound : AVAudioPlayer?

let path2 = Bundle.main.path(forResource: "errorebuono.mp3", ofType:nil)!
let url2 = URL(fileURLWithPath: path2)

var matteosignup : AVAudioPlayer?

let path1 = Bundle.main.path(forResource: "matteoSignup.m4a", ofType:nil)!
let url1 = URL(fileURLWithPath: path1)


struct ContentView : View {
    var body: some View {
        ZStack {
            
//            HStack{
                Image(uiImage: UIImage(named:"enter.png")!)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 200, height: 350)
                
                
                
                    .frame(width:400, height: 600)
//            }
            VStack{
                
                Text("Next morning, Luis decides to sign up for the game , using different usernames, but the system tells \"Name Already Taken\"")
                    .italic()
                    .frame(width:400)
                    .scaledToFit()
                    .lineLimit(4)
                    .font(.system(size: 24, weight: .bold, design: .serif))
                
                Spacer()
                
                HStack{
                    
                    
                    Button {
                    } label :{
                        Text ("SIGN UP")
                            .foregroundColor(.white)
                            .bold()
                            .padding(10).background(.blue)
                            .cornerRadius(10)
                            
                            .scaledToFit()
                        
                            .onTapGesture (count : 1){
                                do {
                                    errorSound = try AVAudioPlayer(contentsOf: url2)
                                    errorSound?.play()
                                } catch {
                                }
                            }
                        
                    }
                                    
                    
                    Button{
                    } label:{
                        Text("PLAY STORY")
                            .foregroundColor(.white)
                            .bold()
                            .padding(10).background(.blue)
                            .cornerRadius(10)
                            
                            .scaledToFit()
                            .onTapGesture (count : 1){
                                do {
                                    matteosignup = try AVAudioPlayer(contentsOf: url1)
                                    matteosignup?.play()
                                } catch {
                                }
                            }
                    }
                }
            }
        }
    }
    
    
}


PlaygroundPage.current.setLiveView(ContentView())

//: [Next](@next)
