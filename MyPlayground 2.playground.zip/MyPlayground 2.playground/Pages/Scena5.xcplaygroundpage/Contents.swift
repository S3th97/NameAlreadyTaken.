//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport
import AVFoundation
import AVFAudio


var barSound : AVAudioPlayer?
var narratore : AVAudioPlayer?

let path1 = Bundle.main.path(forResource: "matteobar.m4a", ofType:nil)!
let url1 = URL(fileURLWithPath: path1)

let path = Bundle.main.path(forResource: "bar.mp3", ofType:nil)!
let url = URL(fileURLWithPath: path)


do {
    barSound = try AVAudioPlayer(contentsOf: url)
    barSound?.play()
    barSound?.volume = 0.5
} catch {
    
}

struct ContentView : View {
    var body: some View {
        ZStack {
            
            
            Image(uiImage: UIImage(named:"scena_4-2.jpg")!)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 200, height: 350)
            
            
                .frame(width:400, height: 600)
            
            VStack{
                
                Text("In the afternoon Luis meets a friend of his that already signed up for the game.")
                    .font(.system(size: 24, weight: .light, design: .serif))
                    .italic()
                    .lineLimit(6)
                    .frame(width: 400, height: 200, alignment: .leading)
                    .position(x: 200, y: 70)
                Spacer()
                
                Button {
                } label :{
                    Text ("PLAY STORY")
                        .foregroundColor(.white)
                        .bold()
                        .padding(10).background(.blue)
                        .cornerRadius(10)
                        .position(x: 200, y: 100)
                        .scaledToFit()
                    
                        .onTapGesture (count : 1){
                            do {
                                narratore = try AVAudioPlayer(contentsOf: url1)
                                narratore?.play()
                                narratore?.volume = 4
                            } catch {
                                
                            }
                        }
                    
                }
            }
        }
    }
    
}

PlaygroundPage.current.setLiveView(ContentView())
//: [Next](@next)
